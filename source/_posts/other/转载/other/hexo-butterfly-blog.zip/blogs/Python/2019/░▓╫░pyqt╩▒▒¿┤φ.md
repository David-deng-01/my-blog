---
title: 安装pyqt时报错
tags:
  - pyqt
categories:
  - Python
abbrlink: 7583b932
date: 2019-10-01 12:00:00
updated: 2019-10-01 12:00:00
keywords: pyqt5,python3
description: 安装pyqt时报错
---


安装pyqt5 时出现错误， 提示 `could not fetch URL`，最后检查发现原来是开了fiddler，关闭fiddler即可

    ![](https://cdn.jsdelivr.net/gh/kcyln/ImageHosting@latest/2020/07/28/228d472d3db177a3c03a2f058fdc7505.png)

解决方法链接：<https://blog.csdn.net/jiang_xiaoo24/article/details/87689369>

  ​